import Phaser from 'phaser';
import { Player } from './Player';

const GRAPPLE_MAX_DISTANCE = 400; // Max rope length in pixels
const REEL_SENSITIVITY = 0.4;    // How much each scroll unit changes the target length
const REEL_LERP = 0.15;          // How quickly actual length catches up to target (0–1)

export class GrappleHook {
  private scene: Phaser.Scene;
  private player: Player;

  // The Matter.js constraint representing the rope
  private constraint: MatterJS.ConstraintType | null = null;

  // Where the hook is anchored in world space
  private _anchorPoint: Phaser.Math.Vector2 | null = null;

  // Smooth reeling: we lerp the constraint length toward this target each frame
  private targetRopeLength: number = 0;

  constructor(scene: Phaser.Scene, player: Player) {
    this.scene = scene;
    this.player = player;

    // Left click → fire grapple / release if already attached
    scene.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
      if (pointer.leftButtonDown()) {
        if (this.constraint) {
          this.release();
        } else {
          this.fire(pointer);
        }
      }
    });

    // Scroll wheel → reel in / out
    scene.input.on('wheel', (_pointer: Phaser.Input.Pointer, _gameObjects: unknown, _dx: number, dy: number) => {
      this.reel(dy);
    });
  }

  get anchorPoint(): Phaser.Math.Vector2 | null {
    return this._anchorPoint;
  }

  update(): void {
    if (!this.constraint) return;

    // Smoothly lerp the actual constraint length toward the scroll target
    const current = this.constraint.length as number;
    const next = Phaser.Math.Linear(current, this.targetRopeLength, REEL_LERP);
    (this.constraint as MatterJS.ConstraintType).length = next;
  }

  // ── Firing ──────────────────────────────────────────────────────────────────

  private fire(pointer: Phaser.Input.Pointer): void {
    const playerPos = this.player.position;

    // Direction from player toward cursor (world space)
    const dir = new Phaser.Math.Vector2(
      pointer.worldX - playerPos.x,
      pointer.worldY - playerPos.y
    );

    if (dir.length() < 1) return;
    dir.normalize();

    // Always cast the full max distance — cursor position only sets direction
    const hit = this.raycast(playerPos, dir, GRAPPLE_MAX_DISTANCE);

    if (!hit) return; // Nothing in that direction within range

    this._anchorPoint = hit;

    const ropeLength = Phaser.Math.Distance.Between(
      playerPos.x,
      playerPos.y,
      hit.x,
      hit.y
    );

    // Initialise target to current length so there's no immediate lerp jump
    this.targetRopeLength = ropeLength;

    this.constraint = this.scene.matter.add.constraint(
      this.player.matterBody as MatterJS.BodyType,
      this.makeAnchorBody(hit.x, hit.y),
      ropeLength,
      0, // stiffness 0 = rope (pulls when taut, never pushes)
      {
        pointA: { x: 0, y: 0 },
        pointB: { x: 0, y: 0 },
      }
    ) as MatterJS.ConstraintType;
  }

  private release(): void {
    if (this.constraint) {
      this.scene.matter.world.removeConstraint(this.constraint);
      this.constraint = null;
      this._anchorPoint = null;
    }
  }

  // ── Reeling ─────────────────────────────────────────────────────────────────

  private reel(dy: number): void {
    if (!this.constraint) return;

    // dy > 0 = scroll down = reel out (longer rope)
    // dy < 0 = scroll up  = reel in  (shorter rope)
    // Adjust the TARGET — update() lerps the actual constraint toward it each frame
    this.targetRopeLength = Math.max(
      20,
      Math.min(GRAPPLE_MAX_DISTANCE, this.targetRopeLength + dy * REEL_SENSITIVITY)
    );
  }

  // ── Helpers ─────────────────────────────────────────────────────────────────

  /**
   * Simple ray-vs-AABB test against all static bodies (platforms).
   * Returns the first hit point, or null.
   */
  private raycast(
    origin: Phaser.Math.Vector2,
    direction: Phaser.Math.Vector2,
    maxDist: number
  ): Phaser.Math.Vector2 | null {
    // Phaser's matter world gives us access to all bodies
    const bodies = this.scene.matter.world.getAllBodies() as MatterJS.BodyType[];
    const staticBodies = bodies.filter((b) => b.isStatic && b.label === 'platform');

    let closestHit: Phaser.Math.Vector2 | null = null;
    let closestDist = maxDist;

    for (const body of staticBodies) {
      const bounds = body.bounds;
      const hit = this.rayVsAABB(origin, direction, bounds, closestDist);
      if (hit !== null) {
        const d = Phaser.Math.Distance.Between(origin.x, origin.y, hit.x, hit.y);
        if (d < closestDist) {
          closestDist = d;
          closestHit = hit;
        }
      }
    }

    return closestHit;
  }

  /**
   * Ray vs AABB intersection. Returns hit point or null.
   */
  private rayVsAABB(
    origin: Phaser.Math.Vector2,
    dir: Phaser.Math.Vector2,
    bounds: { min: { x: number; y: number }; max: { x: number; y: number } },
    maxDist: number
  ): Phaser.Math.Vector2 | null {
    const invDirX = dir.x !== 0 ? 1 / dir.x : Infinity;
    const invDirY = dir.y !== 0 ? 1 / dir.y : Infinity;

    const t1 = (bounds.min.x - origin.x) * invDirX;
    const t2 = (bounds.max.x - origin.x) * invDirX;
    const t3 = (bounds.min.y - origin.y) * invDirY;
    const t4 = (bounds.max.y - origin.y) * invDirY;

    const tmin = Math.max(Math.min(t1, t2), Math.min(t3, t4));
    const tmax = Math.min(Math.max(t1, t2), Math.max(t3, t4));

    if (tmax < 0 || tmin > tmax || tmin > maxDist) return null;

    const t = tmin < 0 ? tmax : tmin;
    return new Phaser.Math.Vector2(origin.x + dir.x * t, origin.y + dir.y * t);
  }

  /**
   * Creates a tiny invisible static body at the anchor point.
   * Matter.js constraints need two bodies — this is the fixed end.
   */
  private makeAnchorBody(x: number, y: number): MatterJS.BodyType {
    return this.scene.matter.add.rectangle(x, y, 2, 2, {
      isStatic: true,
      isSensor: true,    // Won't collide with anything
      label: 'anchor',
    }) as MatterJS.BodyType;
  }
}
