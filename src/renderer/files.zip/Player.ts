import Phaser from 'phaser';

const WALK_SPEED = 5;       // Horizontal velocity applied per frame
const JUMP_FORCE = -18;     // Vertical impulse on jump (stronger to match gravity 2.5)
const MAX_FALL_SPEED = 30;  // Terminal velocity
const COYOTE_TIME_MS = 100; // Grace period after walking off an edge
const JUMP_BUFFER_MS = 120; // Pre-press jump before landing

export class Player {
  readonly scene: Phaser.Scene;
  readonly gameObject: Phaser.GameObjects.Rectangle;

  private body: MatterJS.BodyType;
  private cursors: Phaser.Types.Input.Keyboard.CursorKeys;
  private wasd: {
    up: Phaser.Input.Keyboard.Key;
    left: Phaser.Input.Keyboard.Key;
    right: Phaser.Input.Keyboard.Key;
  };

  // Ground detection
  private isGrounded: boolean = false;
  private coyoteTimer: number = 0;
  private jumpBufferTimer: number = 0;

  // Track whether jump key was just pressed (to avoid hold-to-jump)
  private jumpKeyDown: boolean = false;

  constructor(scene: Phaser.Scene, x: number, y: number) {
    this.scene = scene;

    const W = 28;
    const H = 40;

    // Visual
    this.gameObject = scene.add.rectangle(x, y, W, H, 0xe8e8e8);

    // Physics body — attach to the visual rectangle
    this.body = scene.matter.add.rectangle(x, y, W, H, {
      label: 'player',
      frictionAir: 0.05,   // Light air resistance
      friction: 0.01,      // Low ground friction (we control speed manually)
      restitution: 0,      // No bounciness
      inertia: Infinity,   // Prevent rotation — players don't tumble
    }) as MatterJS.BodyType;

    // Detect when player touches the ground
    scene.matter.world.on('collisionstart', this.onCollisionStart, this);
    scene.matter.world.on('collisionend', this.onCollisionEnd, this);

    // Input
    this.cursors = scene.input.keyboard!.createCursorKeys();
    this.wasd = {
      up: scene.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.W),
      left: scene.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.A),
      right: scene.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.D),
    };
  }

  get position(): Phaser.Math.Vector2 {
    return new Phaser.Math.Vector2(this.body.position.x, this.body.position.y);
  }

  get matterBody(): MatterJS.BodyType {
    return this.body;
  }

  update(delta: number): void {
    this.syncVisual();
    this.handleMovement();
    this.handleJump(delta);
    this.clampFallSpeed();
  }

  private syncVisual(): void {
    this.gameObject.setPosition(this.body.position.x, this.body.position.y);
  }

  private handleMovement(): void {
    const left = this.cursors.left.isDown || this.wasd.left.isDown;
    const right = this.cursors.right.isDown || this.wasd.right.isDown;

    const vel = this.body.velocity;

    if (left) {
      this.scene.matter.body.setVelocity(this.body, { x: -WALK_SPEED, y: vel.y });
    } else if (right) {
      this.scene.matter.body.setVelocity(this.body, { x: WALK_SPEED, y: vel.y });
    } else {
      // Dampen horizontal velocity when no key is held
      this.scene.matter.body.setVelocity(this.body, { x: vel.x * 0.8, y: vel.y });
    }
  }

  private handleJump(delta: number): void {
    const wantsJump =
      Phaser.Input.Keyboard.JustDown(this.cursors.up) ||
      Phaser.Input.Keyboard.JustDown(this.cursors.space) ||
      Phaser.Input.Keyboard.JustDown(this.wasd.up);

    if (wantsJump) {
      this.jumpBufferTimer = JUMP_BUFFER_MS;
    }

    // Tick timers
    if (this.isGrounded) {
      this.coyoteTimer = COYOTE_TIME_MS;
    } else {
      this.coyoteTimer = Math.max(0, this.coyoteTimer - delta);
    }
    this.jumpBufferTimer = Math.max(0, this.jumpBufferTimer - delta);

    // Fire jump if buffer and coyote both active
    if (this.jumpBufferTimer > 0 && this.coyoteTimer > 0) {
      const vel = this.body.velocity;
      this.scene.matter.body.setVelocity(this.body, { x: vel.x, y: JUMP_FORCE });
      this.coyoteTimer = 0;
      this.jumpBufferTimer = 0;
    }
  }

  private clampFallSpeed(): void {
    const vel = this.body.velocity;
    if (vel.y > MAX_FALL_SPEED) {
      this.scene.matter.body.setVelocity(this.body, { x: vel.x, y: MAX_FALL_SPEED });
    }
  }

  private onCollisionStart(
    event: Phaser.Physics.Matter.Events.CollisionStartEvent
  ): void {
    for (const pair of event.pairs) {
      const bodies = [pair.bodyA, pair.bodyB] as MatterJS.BodyType[];
      const isPlayer = bodies.some((b) => b === this.body);
      const isPlatform = bodies.some((b) => b.label === 'platform');
      if (isPlayer && isPlatform) {
        this.isGrounded = true;
      }
    }
  }

  private onCollisionEnd(
    event: Phaser.Physics.Matter.Events.CollisionEndEvent
  ): void {
    for (const pair of event.pairs) {
      const bodies = [pair.bodyA, pair.bodyB] as MatterJS.BodyType[];
      const isPlayer = bodies.some((b) => b === this.body);
      const isPlatform = bodies.some((b) => b.label === 'platform');
      if (isPlayer && isPlatform) {
        this.isGrounded = false;
      }
    }
  }
}
